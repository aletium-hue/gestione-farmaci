/**
 * BACKUP "GESTIONE FARMACI" SU GOOGLE DRIVE
 * --------------------------------------------------
 * Questo script gira SOTTO IL TUO account Google: ha quindi il permesso
 * di scrivere nella tua cartella Drive senza che tu inserisca password
 * dentro l'app. L'app invia qui i dati e lo script crea/aggiorna il file.
 *
 * COME ATTIVARLO (una volta sola):
 * 1) Vai su https://script.google.com  ->  "Nuovo progetto".
 * 2) Cancella il contenuto e incolla TUTTO questo file.
 * 3) Cambia SECRET con un token a tua scelta (una parola segreta).
 * 4) In alto: "Distribuisci" -> "Nuova distribuzione" -> tipo "App web".
 *      - Esegui come: Me (il tuo account)
 *      - Chi ha accesso: Chiunque
 * 5) Autorizza quando richiesto, poi COPIA l'URL che finisce con /exec.
 * 6) Nell'app: ☰ -> Impostazioni backup Drive -> incolla URL e lo stesso token.
 */

// La tua cartella Drive (già impostata sul link che hai fornito):
const FOLDER_ID = '1c8nkqvF4YWW3bHim5Hp6ATMl9dQsS4sl';

// CAMBIA questo token e usa lo STESSO valore nell'app:
const SECRET = 'CAMBIA-QUESTO-TOKEN';

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents);
    if (String(body.token) !== String(SECRET)) {
      return json({ ok: false, error: 'token non valido' });
    }
    const folder = DriveApp.getFolderById(FOLDER_ID);
    const name = body.filename || ('GestioneFarmaci_backup.json');
    const content = body.data || '{}';

    // Mantiene anche una copia datata + un file "ultimo" sempre aggiornato
    const dated = name.replace(/\.json$/i, '') + '_' +
                  Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd_HH-mm') + '.json';
    folder.createFile(dated, content, 'application/json');

    const existing = folder.getFilesByName(name);
    while (existing.hasNext()) existing.next().setTrashed(true);
    folder.createFile(name, content, 'application/json');

    return json({ ok: true });
  } catch (err) {
    return json({ ok: false, error: String(err) });
  }
}

function doGet() {
  return ContentService.createTextOutput('Endpoint backup Gestione Farmaci attivo.');
}

function json(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
