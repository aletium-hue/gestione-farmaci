package com.stefani.gestionefarmaci;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private WebView web;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_CODE = 1001;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);    // localStorage persistente
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);

        web.setWebViewClient(new WebViewClient());

        // Necessario per <input type="file"> (importa backup)
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "Seleziona backup"), FILE_CHOOSER_CODE);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == FILE_CHOOSER_CODE) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (res == RESULT_OK && data != null && data.getData() != null) {
                results = new Uri[]{ data.getData() };
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    /* Ponte JavaScript <-> Android */
    class Bridge {

        @JavascriptInterface
        public void addCalendarEvent(final String title, final String description, final long beginMillis) {
            runOnUiThread(new Runnable() { public void run() {
                try {
                    Intent i = new Intent(Intent.ACTION_INSERT)
                        .setData(CalendarContract.Events.CONTENT_URI)
                        .putExtra(CalendarContract.Events.TITLE, title)
                        .putExtra(CalendarContract.Events.DESCRIPTION, description)
                        .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, beginMillis)
                        .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, beginMillis + 30L * 60L * 1000L);
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (Exception e) {
                    toast("Nessuna app calendario trovata sul telefono.");
                }
            }});
        }

        @JavascriptInterface
        public void openUrl(final String url) {
            runOnUiThread(new Runnable() { public void run() {
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (Exception e) {
                    toast("Impossibile aprire il link.");
                }
            }});
        }

        @JavascriptInterface
        public void saveToDownloads(final String filename, final String content) {
            runOnUiThread(new Runnable() { public void run() {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentValues cv = new ContentValues();
                        cv.put(MediaStore.Downloads.DISPLAY_NAME, filename);
                        cv.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                        cv.put(MediaStore.Downloads.IS_PENDING, 1);
                        ContentResolver r = getContentResolver();
                        Uri item = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                        OutputStream os = r.openOutputStream(item);
                        os.write(content.getBytes("UTF-8"));
                        os.close();
                        cv.clear();
                        cv.put(MediaStore.Downloads.IS_PENDING, 0);
                        r.update(item, cv, null, null);
                        toast("Backup salvato in Download: " + filename);
                    } else {
                        File dir = getExternalFilesDir(null);
                        File f = new File(dir, filename);
                        FileOutputStream fo = new FileOutputStream(f);
                        fo.write(content.getBytes("UTF-8"));
                        fo.close();
                        toast("Backup salvato: " + f.getAbsolutePath());
                    }
                } catch (Exception e) {
                    toast("Salvataggio non riuscito: " + e.getMessage());
                }
            }});
        }

        @JavascriptInterface
        public void toast(final String msg) {
            runOnUiThread(new Runnable() { public void run() {
                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
            }});
        }
    }
}
