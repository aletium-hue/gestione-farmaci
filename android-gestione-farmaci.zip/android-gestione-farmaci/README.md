# Gestione Farmaci — APK per Samsung Z Fold 7

App per gestire le somministrazioni dei farmaci, con:
- 4 pulsanti programmabili (tap lungo = nome farmaco, tap = seleziona)
- calendario mensile scorrevole, dose 1ª–1.000ª, differenza in giorni dall'ultima dose
- **salvataggio nel Calendario del telefono** dopo ogni dose (sopravvive ad aggiornamenti)
- **backup su Google Drive** + esporta/importa file di backup

Genera un **vero APK firmato** compilato gratis nel cloud da GitHub Actions.

--------------------------------------------------------------------

## A) Creare l'APK (GitHub Actions)

1. Vai su https://github.com → accedi → **+** → **New repository** → dai un nome → **Create**.
2. Nel repo: **Add file → Upload files**, trascina **tutto il contenuto** della cartella
   estratta (`.github`, `app`, `google-drive-backup`, `build.gradle`, ecc.) → **Commit**.
3. Scheda **Actions**: attendi il pallino verde di **Build APK** (1–3 min).
   Se non parte: **Actions → Build APK → Run workflow**.
4. Apri il job → **Artifacts** → scarica **GestioneFarmaci-APK** → estrai → **GestioneFarmaci.apk**.
5. Sul Fold 7: apri l'APK, consenti l'installazione da fonti sconosciute, installa.

--------------------------------------------------------------------

## B) Salvataggio nel Calendario (automatico)

Dopo aver salvato una dose, l'app chiede se aggiungerla al **Calendario del telefono**.
- Sul Samsung apre la schermata "nuovo evento" del calendario già compilata: tocca **Salva**.
- Usa lo standard iCalendar (.ics), lo stesso di Apple Calendar: se sincronizzi un
  account iCloud sul telefono, l'evento finisce anche lì.
- I dati nel calendario restano anche se aggiorni o reinstalli l'app.

--------------------------------------------------------------------

## C) Backup su Google Drive (sicuro, senza password)

> ⚠️ Per sicurezza l'app **non chiede mai email o password Google** (Google lo vieta
> nelle app). L'accesso al tuo Drive avviene tramite uno script che attivi tu, una
> volta sola, sul tuo account.

1. Apri https://script.google.com → **Nuovo progetto**.
2. Incolla il contenuto di `google-drive-backup/Codice.gs`.
3. Cambia `SECRET` con un token a tua scelta (una parola segreta).
4. **Distribuisci → Nuova distribuzione → App web**:
   - *Esegui come*: Me  
   - *Chi ha accesso*: Chiunque
5. Autorizza, poi copia l'**URL** che termina con `/exec`.
6. Nell'app: **☰ → Impostazioni backup Drive** → incolla URL e lo **stesso token**.
7. Da **☰ → Backup su Google Drive** il file finisce nella tua cartella:
   https://drive.google.com/drive/u/0/folders/1c8nkqvF4YWW3bHim5Hp6ATMl9dQsS4sl
   (viene salvato un file "ultimo" sempre aggiornato + una copia datata di archivio.)

**Senza alcuna configurazione** puoi comunque usare **☰ → Esporta backup (file)**:
salva un `.json` nei Download, che poi carichi a mano su Drive. E **Importa / ripristina
backup** ricarica i dati dopo una reinstallazione.

--------------------------------------------------------------------

## Note
- Permesso Internet richiesto solo per il backup Drive che avvii tu manualmente.
- minSdk 26 (Android 8+), targetSdk 34 — compatibile con il Fold 7, schermo esterno e interno.
- I dati interni all'app si azzerano se la disinstalli: usa Calendario e/o backup Drive
  come copia sicura.
- Per aggiornare l'app mantenendo gli stessi dati senza disinstallare, vedi la sezione
  keystore opzionale (Secrets) qui sotto.

### (Opzionale) Firma fissa per aggiornamenti senza disinstallare
In **Settings → Secrets and variables → Actions** del repo aggiungi:
`KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
Se presenti, il workflow li usa; altrimenti genera una firma automatica.
